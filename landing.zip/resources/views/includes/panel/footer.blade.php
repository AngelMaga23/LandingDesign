<div class="footer-top pt-110 pb-70">
    <div class="container-footer">
        <div class="row">
            <div class="col-md-4">
                <div class="footer-card">
                    <h3>Dirección</h3>
                    <p>Lorem ipsum dolor sit amet.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="footer-card">
                    <h3>Siguenos</h3>
                    <div class="footer-social text-center">
                        <ul class="social-list mb--0 list-social">
                            <li>
                                <a href="#">
                                    <i class="fab fa-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fab fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fab fa-instagram"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="footer-card">
                    <h3>Contanto</h3>
                    <p>Lorem ipsum dolor sit amet.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="footer-bottom text-center">
    <p>{{ config('app.name') }}</p>
</div>