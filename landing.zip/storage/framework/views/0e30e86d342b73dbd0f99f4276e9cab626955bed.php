<div class="col-md-12" style="font-family: 'Exo 2', sans-serif">
    <div class="row">
        <div class="col-md-12" style="margin-bottom: 10px, font-size:20px">
            <div class="form-group">
                <label style="margin-bottom: 10px, font-size:10px, font-weight:700">Nombre: </label>
                <p><?php echo e($nombre); ?></p>
            </div>
        </div>

        <div class="col-md-6" style="margin-bottom: 10px, font-size:20px">
            <label style="margin-bottom: 10px, font-size:20px, font-weight:700">Marca: </label>
            <p><?php echo e($marca); ?></p>
        </div>
        <div class="col-md-6" style="margin-bottom: 10px, font-size:20px">
            <label style="margin-bottom: 10px, font-size:20px, font-weight:700">Modelo</label>
            <p><?php echo e($modelo); ?></p>
        </div>

        <div class="col-md-12" style="margin-bottom: 10px, font-size:20px">
            <img src="<?php echo e("data:image/png;base64,". $imagen); ?>" width="200px" height="200px" style="object-fit: cover">
        </div>

    </div>
</div><?php /**PATH C:\xampp\htdocs\landing\resources\views/contact-mail.blade.php ENDPATH**/ ?>