<a href="<?php echo e(url('/')); ?>" class="logo"></a>

<nav id="inicio">
    <ul>
        <li>
            <a href="<?php echo e(url('/')); ?>" class="<?php echo e(request()->route()->named('/*') ? 'activo' : ''); ?>">Inicio</a>
        </li>
        <li class="services-options">
            <i class="fa fa-caret-square-o-down"></i>
            <a href="#">Servicios</a>
            <ul class="services">
                <li>
                    <a href="#cards-services">Venta</a>
                </li>
                <li>
                    <a href="#cards-services">Renta</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(url('contacto')); ?>" class="<?php echo e(request()->route()->named('contacto*') ? 'activo' : ''); ?>">Contacto</a>
        </li>
    </ul>
</nav><?php /**PATH C:\xampp\htdocs\landing\resources\views/includes/panel/menu.blade.php ENDPATH**/ ?>